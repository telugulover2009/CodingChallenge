﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CustomerInfoApi.Utility
{ 

    public class DateOfBirthAttribute : ValidationAttribute
    {
        public int MinAge { get; set; }
        //public int MaxAge { get; set; }

        public override bool IsValid(object value)
        {
            if (value == null)
                return true;

            var val = (DateTime)value;

            if (val.AddYears(MinAge) > DateTime.Now)
                return false;

            return true;
            //return (val.AddYears(MaxAge) > DateTime.Now);
        }
    }
}