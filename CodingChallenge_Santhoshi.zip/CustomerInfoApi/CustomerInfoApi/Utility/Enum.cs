﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CustomerInfoApi.Utility
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}