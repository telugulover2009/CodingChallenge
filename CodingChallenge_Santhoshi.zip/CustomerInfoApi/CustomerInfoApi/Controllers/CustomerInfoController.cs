﻿using CustomerInfoApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Text.Json;
using System.IO;
using System.Configuration;

namespace CustomerInfoApi.Controllers
{
    public class CustomerInfoController : ApiController
    {
        
        // POST api/values
        public  IHttpActionResult Post([FromBody]CustomerInfo customer)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
             
            List<string> addresses = new List<string>();
            addresses.Add(customer.Address1);
            addresses.Add(customer.Address2);
            addresses.Add(customer.Address3);

            var jsonString = JsonSerializer.Serialize(customer, new JsonSerializerOptions { WriteIndented = true }); ;

            var fileName = string.Format("cust_info_{0}.json", DateTime.Now.ToString("yyyyMMddHHmmss")); //cust_info_20200501130220.json

            var configFolder = ConfigurationManager.AppSettings["JSONFolder"];

            if (!Directory.Exists(configFolder))
                Directory.CreateDirectory(configFolder);

            File.WriteAllText(configFolder + fileName, jsonString);
             
            return Ok("Information saved successfully.");

        }


    }
}
