﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.IO; 
using CodingChallenge.Web.Models;
using System.Text.Json;

namespace CodingChallenge.Web.Controllers
{
    public class CustomerInfoController : Controller
    {
        // GET: CustomerInfo
        public ActionResult Index()
        {
            return View();
        }

        // GET: CustomerInfo/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: CustomerInfo/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CustomerInfo/Create
        [HttpPost]
        public ActionResult Create(CustomerInfo customer)
        {
            try
            {
                List<string> addresses = new List<string>();
                addresses.Add(customer.Address1);
                addresses.Add(customer.Address2);
                addresses.Add(customer.Address3);

                var jsonString = JsonSerializer.Serialize(customer, new JsonSerializerOptions { WriteIndented = true }); ;

                var fileName = string.Format("cust_info_{0}.json", DateTime.Now.ToString("yyyyMMddHHmmss")); //cust_info_20200501130220.json

                var configFolder = ConfigurationManager.AppSettings["JSONFolder"];

                if (!Directory.Exists(configFolder))
                    Directory.CreateDirectory(configFolder);

                System.IO.File.WriteAllText(configFolder + fileName, jsonString);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: CustomerInfo/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: CustomerInfo/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult ViewPdf(int id)
        {
            ViewBag.Id = id;
            return PartialView("TnCPreview");
        }

        public ActionResult ShowModalDocument()
        {
            string filePath = ConfigurationManager.AppSettings["TnCPath"];
            var contentDisposition = new System.Net.Mime.ContentDisposition
            {
                FileName = "TnC.pdf",
                Inline = true
            };
            Response.Headers.Add("Content-Disposition", contentDisposition.ToString());
            return File(filePath, System.Net.Mime.MediaTypeNames.Application.Pdf);
        }
    }
}
