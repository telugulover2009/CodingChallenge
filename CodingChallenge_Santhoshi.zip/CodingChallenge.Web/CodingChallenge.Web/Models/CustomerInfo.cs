﻿using CodingChallenge.Web.Utility;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using static CodingChallenge.Web.Utility.Constant;

namespace CodingChallenge.Web.Models
{
    public class CustomerInfo
    {
        [DisplayName("First Name")]
        [Required(ErrorMessage = "First Name is required")]
        [StringLength(30, ErrorMessage = "First name cannot exceed 30 characters")]
        [RegularExpression("^[A-Za-z0-9]*$", ErrorMessage = "First name cannot contain special characters")]
        public string first_name { get; set; }

        [DisplayName("Middle Name")]
        [StringLength(30, ErrorMessage = "Middle name cannot exceed 30 characters")]
        [RegularExpression("^[A-Za-z0-9]*$", ErrorMessage = "Middle name cannot contain special characters")]
        public string middle_name { get; set; }

        [DisplayName("Last Name")]
        [Required(ErrorMessage = "Last Name is required")]
        [StringLength(30, ErrorMessage = "Last name cannot exceed 30 characters")]
        [RegularExpression("^[A-Za-z0-9]*$", ErrorMessage = "Last name cannot contain special characters")]
        public string last_name { get; set; }

        [DisplayName("Mobile")]
        [Required(ErrorMessage = "Mobile number is required")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Mobile number should contain numeric values only.")]
        public long mobile { get; set; }

        [Required(ErrorMessage = "Email Address is required")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email")]
        [MaxLength(50)]
        [RegularExpression("^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string email { get; set; }

        [EnumDataType(typeof(Gender))]

        [DisplayName("Gender")]
        public string gender { get; set; } = Gender.Male.ToString();

        [Required(ErrorMessage = "Date of Birth is required")]
        [DisplayName("Date of Birth")]
        [DateOfBirth(MinAge = 18, ErrorMessage = "Age must not be less-than 18 years")]
        public string dob { get; set; }

        [DisplayName("Accept communication via Mobile")]
        public bool accept_communication_via_mobile { get; set; } = true;

        [DisplayName("Accept communication via Email")]
        public bool accept_communication_via_email { get; set; } = true;

        [DisplayName("Read our Terms & Conditions")]
        public bool tnc_accepted { get; set; } = true;

        [JsonIgnore]
        [StringLength(30, ErrorMessage = "Address1 cannot exceed 30 characters")]
        public string Address1 { get; set; }
        [JsonIgnore]
        [StringLength(30, ErrorMessage = "Address2 cannot exceed 30 characters")]
        public string Address2 { get; set; }
        [JsonIgnore]
        [StringLength(30, ErrorMessage = "Address3 cannot exceed 30 characters")]
        public string Address3 { get; set; }

        public List<string> address { get; set; }


    }
}