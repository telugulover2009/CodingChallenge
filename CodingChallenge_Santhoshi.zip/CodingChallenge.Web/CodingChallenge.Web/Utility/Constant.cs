﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodingChallenge.Web.Utility
{
    public class Constant
    {
        public enum Gender
        {
            Male,
            Female,
            Other
        }
    }
}